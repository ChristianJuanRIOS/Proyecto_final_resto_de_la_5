import { useEffect, useRef } from 'react'
import '../styles/Modal.css'

function Modal({ titulo, onClose, children, maxAncho = 500, cerrable = true }) {
  const dialogoRef = useRef(null)

  useEffect(() => {
    dialogoRef.current?.focus()

    function handleKeyDown(e) {
      if (e.key === 'Escape' && cerrable) {
        onClose()
      }
    }
    document.addEventListener('keydown', handleKeyDown)

    const overflowAnterior = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = overflowAnterior
    }
  }, [onClose, cerrable])

  function handleOverlayClick(e) {
    if (!cerrable) return
    if (e.target === e.currentTarget) onClose()
  }

  return (
    <div
      className="modal-overlay"
      onMouseDown={handleOverlayClick}
    >
      <div
        ref={dialogoRef}
        className="modal-dialog"
        role="dialog"
        aria-modal="true"
        aria-label={titulo}
        tabIndex={-1}
        style={{ maxWidth: maxAncho }}
      >
        <div className="modal-header">
          <h3>{titulo}</h3>
          {cerrable && (
            <button
              type="button"
              className="modal-close"
              onClick={onClose}
              aria-label="Cerrar"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>
        <div className="modal-body">
          {children}
        </div>
      </div>
    </div>
  )
}

export default Modal